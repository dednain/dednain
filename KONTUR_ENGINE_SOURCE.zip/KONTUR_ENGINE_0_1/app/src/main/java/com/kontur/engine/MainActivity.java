package com.kontur.engine;

import android.app.Activity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.opengl.GLSurfaceView;
import android.content.Context;

public class MainActivity extends Activity {
    private EngineView gameView;

    static {
        System.loadLibrary("kontur");
    }

    private static native void nativeOnSurfaceCreated();
    private static native void nativeOnSurfaceChanged(int width, int height);
    private static native void nativeOnDrawFrame();
    private static native void nativeSetMove(float x, float y);
    private static native void nativeLook(float dx, float dy);
    private static native void nativeFire();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        hideSystemUi();
        gameView = new EngineView(this);
        setContentView(gameView);
    }

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (gameView != null) gameView.onResume();
        hideSystemUi();
    }

    @Override
    protected void onPause() {
        if (gameView != null) gameView.onPause();
        super.onPause();
    }

    private static class EngineView extends GLSurfaceView {
        private int movePointer = -1;
        private int lookPointer = -1;
        private int firePointer = -1;

        private float moveOriginX;
        private float moveOriginY;
        private float lastLookX;
        private float lastLookY;
        private final float stickRadius = 105.0f;

        EngineView(Context context) {
            super(context);
            setEGLContextClientVersion(3);
            setEGLConfigChooser(8, 8, 8, 8, 16, 0);
            setPreserveEGLContextOnPause(true);
            setRenderer(new Renderer());
            setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
            setFocusable(true);
        }

        private static float clamp(float value, float min, float max) {
            return Math.max(min, Math.min(max, value));
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            final int action = event.getActionMasked();
            final int index = event.getActionIndex();

            if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
                final int id = event.getPointerId(index);
                final float x = event.getX(index);
                final float y = event.getY(index);
                final float w = getWidth();
                final float h = getHeight();

                if (x < w * 0.43f && movePointer == -1) {
                    movePointer = id;
                    moveOriginX = x;
                    moveOriginY = y;
                    nativeSetMove(0.0f, 0.0f);
                } else if (x > w * 0.78f && y > h * 0.66f && firePointer == -1) {
                    firePointer = id;
                    nativeFire();
                } else if (lookPointer == -1) {
                    lookPointer = id;
                    lastLookX = x;
                    lastLookY = y;
                }
                return true;
            }

            if (action == MotionEvent.ACTION_MOVE) {
                for (int i = 0; i < event.getPointerCount(); i++) {
                    int id = event.getPointerId(i);
                    float x = event.getX(i);
                    float y = event.getY(i);

                    if (id == movePointer) {
                        float dx = (x - moveOriginX) / stickRadius;
                        float dy = (y - moveOriginY) / stickRadius;
                        float length = (float)Math.sqrt(dx * dx + dy * dy);
                        if (length > 1.0f) {
                            dx /= length;
                            dy /= length;
                        }
                        nativeSetMove(clamp(dx, -1.0f, 1.0f), clamp(dy, -1.0f, 1.0f));
                    } else if (id == lookPointer) {
                        float dx = x - lastLookX;
                        float dy = y - lastLookY;
                        lastLookX = x;
                        lastLookY = y;
                        nativeLook(dx * 0.0045f, dy * 0.0045f);
                    }
                }
                return true;
            }

            if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP
                    || action == MotionEvent.ACTION_CANCEL) {
                int id = (action == MotionEvent.ACTION_CANCEL) ? -1 : event.getPointerId(index);
                if (id == movePointer || action == MotionEvent.ACTION_CANCEL) {
                    movePointer = -1;
                    nativeSetMove(0.0f, 0.0f);
                }
                if (id == lookPointer || action == MotionEvent.ACTION_CANCEL) {
                    lookPointer = -1;
                }
                if (id == firePointer || action == MotionEvent.ACTION_CANCEL) {
                    firePointer = -1;
                }
                return true;
            }
            return true;
        }
    }

    private static class Renderer implements GLSurfaceView.Renderer {
        @Override
        public void onSurfaceCreated(javax.microedition.khronos.opengles.GL10 gl,
                                     javax.microedition.khronos.egl.EGLConfig config) {
            nativeOnSurfaceCreated();
        }

        @Override
        public void onSurfaceChanged(javax.microedition.khronos.opengles.GL10 gl,
                                     int width, int height) {
            nativeOnSurfaceChanged(width, height);
        }

        @Override
        public void onDrawFrame(javax.microedition.khronos.opengles.GL10 gl) {
            nativeOnDrawFrame();
        }
    }
}
