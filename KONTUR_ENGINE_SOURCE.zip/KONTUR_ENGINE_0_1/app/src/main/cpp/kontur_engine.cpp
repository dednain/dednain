#include <jni.h>
#include <GLES3/gl3.h>
#include <android/log.h>

#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <mutex>
#include <string>
#include <vector>

#define LOG_TAG "KONTUR_ENGINE"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace {

constexpr float PI = 3.1415926535f;

struct Vec3 { float x, y, z; };
Vec3 operator+(Vec3 a, Vec3 b) { return {a.x+b.x, a.y+b.y, a.z+b.z}; }
Vec3 operator-(Vec3 a, Vec3 b) { return {a.x-b.x, a.y-b.y, a.z-b.z}; }
Vec3 operator*(Vec3 a, float s) { return {a.x*s, a.y*s, a.z*s}; }
float dot(Vec3 a, Vec3 b) { return a.x*b.x + a.y*b.y + a.z*b.z; }
Vec3 cross(Vec3 a, Vec3 b) { return {a.y*b.z-a.z*b.y, a.z*b.x-a.x*b.z, a.x*b.y-a.y*b.x}; }
Vec3 normalize(Vec3 v) { float len=std::sqrt(std::max(0.000001f,dot(v,v))); return v*(1.0f/len); }

struct Mat4 { float v[16]{}; };
Mat4 identity() { Mat4 m{}; m.v[0]=m.v[5]=m.v[10]=m.v[15]=1.0f; return m; }
Mat4 multiply(const Mat4& a,const Mat4& b) {
    Mat4 out{};
    for(int col=0;col<4;++col) for(int row=0;row<4;++row) {
        float sum=0.0f; for(int k=0;k<4;++k) sum+=a.v[k*4+row]*b.v[col*4+k];
        out.v[col*4+row]=sum;
    }
    return out;
}
Mat4 translation(float x,float y,float z) { Mat4 m=identity(); m.v[12]=x;m.v[13]=y;m.v[14]=z;return m; }
Mat4 scaling(float x,float y,float z) { Mat4 m{};m.v[0]=x;m.v[5]=y;m.v[10]=z;m.v[15]=1.0f;return m; }
Mat4 perspective(float fov,float aspect,float nearP,float farP) {
    Mat4 m{}; float f=1.0f/std::tan(fov*0.5f);m.v[0]=f/std::max(0.1f,aspect);m.v[5]=f;
    m.v[10]=(farP+nearP)/(nearP-farP);m.v[11]=-1.0f;m.v[14]=(2.0f*farP*nearP)/(nearP-farP);return m;
}
Mat4 lookAt(Vec3 eye,Vec3 center,Vec3 up) {
    Vec3 f=normalize(center-eye),s=normalize(cross(f,up)),u=cross(s,f);Mat4 m=identity();
    m.v[0]=s.x;m.v[1]=u.x;m.v[2]=-f.x;m.v[4]=s.y;m.v[5]=u.y;m.v[6]=-f.y;
    m.v[8]=s.z;m.v[9]=u.z;m.v[10]=-f.z;m.v[12]=-dot(s,eye);m.v[13]=-dot(u,eye);m.v[14]=dot(f,eye);return m;
}

struct Vertex { float px,py,pz,r,g,b; };
GLuint gProgram=0,gCubeVao=0,gCubeVbo=0,gMapVao=0,gMapVbo=0,gOverlayVao=0,gOverlayVbo=0;
GLint gMvpLocation=-1,gTintLocation=-1;
GLsizei gMapVertexCount=0;
int gWidth=1,gHeight=1;float gAspect=1.0f;
Vec3 gPlayer{0.0f,1.65f,7.0f};float gYaw=0.0f,gPitch=0.0f,gMoveX=0.0f,gMoveY=0.0f;
int gFireRequests=0;std::mutex gInputMutex;float gFireFlash=0.0f,gHitFlash=0.0f;
std::chrono::steady_clock::time_point gLastFrame;

struct Target { Vec3 position; int health; bool active; };
std::array<Target,3> gTargets{{
    {{0.0f,1.0f,-13.5f},3,true},{{-4.0f,1.0f,-15.0f},3,true},{{4.0f,1.0f,-16.0f},3,true}
}};

GLuint compileShader(GLenum type,const char* source) {
    GLuint shader=glCreateShader(type);glShaderSource(shader,1,&source,nullptr);glCompileShader(shader);GLint ok=GL_FALSE;glGetShaderiv(shader,GL_COMPILE_STATUS,&ok);
    if(!ok){GLint n=0;glGetShaderiv(shader,GL_INFO_LOG_LENGTH,&n);std::string log(static_cast<size_t>(std::max(1,n)),'\0');glGetShaderInfoLog(shader,n,nullptr,log.data());LOGE("Shader compile failed: %s",log.c_str());glDeleteShader(shader);return 0;}return shader;
}
GLuint createProgram() {
    const char* vs=R"(
        #version 300 es
        precision mediump float;
        layout(location=0) in vec3 aPosition;
        layout(location=1) in vec3 aColor;
        uniform mat4 uMVP;
        uniform vec3 uTint;
        out vec3 vColor;
        void main(){gl_Position=uMVP*vec4(aPosition,1.0);vColor=aColor*uTint;}
    )";
    const char* fs=R"(
        #version 300 es
        precision mediump float;
        in vec3 vColor;
        out vec4 fragColor;
        void main(){fragColor=vec4(vColor,1.0);}
    )";
    GLuint v=compileShader(GL_VERTEX_SHADER,vs),f=compileShader(GL_FRAGMENT_SHADER,fs);if(!v||!f)return 0;
    GLuint p=glCreateProgram();glAttachShader(p,v);glAttachShader(p,f);glLinkProgram(p);GLint ok=GL_FALSE;glGetProgramiv(p,GL_LINK_STATUS,&ok);
    if(!ok){GLint n=0;glGetProgramiv(p,GL_INFO_LOG_LENGTH,&n);std::string log(static_cast<size_t>(std::max(1,n)),'\0');glGetProgramInfoLog(p,n,nullptr,log.data());LOGE("Program link failed: %s",log.c_str());glDeleteProgram(p);p=0;}
    glDeleteShader(v);glDeleteShader(f);return p;
}

void pushFace(std::vector<Vertex>& out,Vec3 a,Vec3 b,Vec3 c,Vec3 d,Vec3 color) {
    Vertex A{a.x,a.y,a.z,color.x,color.y,color.z},B{b.x,b.y,b.z,color.x,color.y,color.z};
    Vertex C{c.x,c.y,c.z,color.x,color.y,color.z},D{d.x,d.y,d.z,color.x,color.y,color.z};
    out.insert(out.end(),{A,B,C,A,C,D});
}
Vec3 shade(Vec3 c,float k){return {std::min(1.0f,c.x*k),std::min(1.0f,c.y*k),std::min(1.0f,c.z*k)};}
Vec3 transformPoint(Vec3 p,Vec3 center,Vec3 size,float yaw) {
    float x=p.x*size.x,z=p.z*size.z,co=std::cos(yaw),si=std::sin(yaw);
    return {center.x+co*x+si*z,center.y+p.y*size.y,center.z-si*x+co*z};
}
void appendBox(std::vector<Vertex>& out,Vec3 c,Vec3 s,Vec3 color,float yaw=0.0f) {
    const float h=0.5f;
    auto P=[&](float x,float y,float z){return transformPoint({x,y,z},c,s,yaw);};
    pushFace(out,P(-h,-h,h),P(h,-h,h),P(h,h,h),P(-h,h,h),shade(color,1.08f));
    pushFace(out,P(h,-h,-h),P(-h,-h,-h),P(-h,h,-h),P(h,h,-h),shade(color,0.70f));
    pushFace(out,P(-h,-h,-h),P(-h,-h,h),P(-h,h,h),P(-h,h,-h),shade(color,0.82f));
    pushFace(out,P(h,-h,h),P(h,-h,-h),P(h,h,-h),P(h,h,h),shade(color,0.90f));
    pushFace(out,P(-h,h,h),P(h,h,h),P(h,h,-h),P(-h,h,-h),shade(color,1.18f));
    pushFace(out,P(-h,-h,-h),P(h,-h,-h),P(h,-h,h),P(-h,-h,h),shade(color,0.58f));
}
void appendQuad(std::vector<Vertex>& out,float x0,float y0,float x1,float y1,float z,Vec3 color) {
    Vertex a{x0,y0,z,color.x,color.y,color.z},b{x1,y0,z,color.x,color.y,color.z};
    Vertex c{x1,y1,z,color.x,color.y,color.z},d{x0,y1,z,color.x,color.y,color.z};
    out.insert(out.end(),{a,b,c,a,c,d});
}
void appendTriangle(std::vector<Vertex>& out,Vec3 a,Vec3 b,Vec3 c,Vec3 color) {
    out.push_back({a.x,a.y,a.z,color.x,color.y,color.z});out.push_back({b.x,b.y,b.z,color.x,color.y,color.z});out.push_back({c.x,c.y,c.z,color.x,color.y,color.z});
}

std::array<uint8_t,7> glyph(char ch) {
    switch(ch) {
    case 'A':return {14,17,17,31,17,17,17}; case 'B':return {30,17,17,30,17,17,30};
    case 'C':return {15,16,16,16,16,16,15}; case 'D':return {30,17,17,17,17,17,30};
    case 'E':return {31,16,16,30,16,16,31}; case 'F':return {31,16,16,30,16,16,16};
    case 'G':return {15,16,16,23,17,17,15}; case 'H':return {17,17,17,31,17,17,17};
    case 'I':return {31,4,4,4,4,4,31}; case 'J':return {7,2,2,2,18,18,12};
    case 'K':return {17,18,20,24,20,18,17}; case 'L':return {16,16,16,16,16,16,31};
    case 'M':return {17,27,21,21,17,17,17}; case 'N':return {17,25,21,19,17,17,17};
    case 'O':return {14,17,17,17,17,17,14}; case 'P':return {30,17,17,30,16,16,16};
    case 'Q':return {14,17,17,17,21,18,13}; case 'R':return {30,17,17,30,20,18,17};
    case 'S':return {15,16,16,14,1,1,30}; case 'T':return {31,4,4,4,4,4,4};
    case 'U':return {17,17,17,17,17,17,14}; case 'V':return {17,17,17,17,17,10,4};
    case 'W':return {17,17,17,21,21,21,10}; case 'X':return {17,17,10,4,10,17,17};
    case 'Y':return {17,17,10,4,4,4,4}; case 'Z':return {31,1,2,4,8,16,31};
    case '0':return {14,17,19,21,25,17,14}; case '1':return {4,12,4,4,4,4,14};
    case '2':return {14,17,1,2,4,8,31}; case '3':return {30,1,1,14,1,1,30};
    case '4':return {2,6,10,18,31,2,2}; case '5':return {31,16,16,30,1,1,30};
    case '6':return {14,16,16,30,17,17,14}; case '7':return {31,1,2,4,8,8,8};
    case '8':return {14,17,17,14,17,17,14}; case '9':return {14,17,17,15,1,1,14};
    case '-':return {0,0,0,31,0,0,0}; default:return {0,0,0,0,0,0,0};
    }
}
void appendText(std::vector<Vertex>& out,const std::string& text,float centerX,float centerY,float z,float px,Vec3 color) {
    const float advance=6.0f*px;float width=text.empty()?0.0f:static_cast<float>(text.size())*advance-px;
    float startX=centerX-width*0.5f;
    for(size_t i=0;i<text.size();++i) {
        auto rows=glyph(text[i]);
        for(int row=0;row<7;++row) for(int col=0;col<5;++col) {
            if((rows[row]&(1u<<(4-col)))==0)continue;
            float x=startX+static_cast<float>(i)*advance+static_cast<float>(col)*px;
            float y=centerY+(3.0f-static_cast<float>(row))*px;
            appendQuad(out,x,y,x+px*0.88f,y+px*0.88f,z,color);
        }
    }
}
void appendRing(std::vector<Vertex>& out,float cx,float cz,float y,float radius,float tube,Vec3 color,int segments=64) {
    for(int i=0;i<segments;++i) {
        float a=(2.0f*PI*static_cast<float>(i))/segments;
        float x=std::cos(a)*radius,z=std::sin(a)*radius;
        appendBox(out,{cx+x,y,cz+z},{tube,0.045f,0.12f},color,a+PI*0.5f);
    }
}
void appendBanner(std::vector<Vertex>& v,float x,float y,float z,bool cyan) {
    Vec3 base={0.035f,0.045f,0.060f};Vec3 accent=cyan?Vec3{0.02f,0.72f,0.95f}:Vec3{0.98f,0.32f,0.08f};
    appendBox(v,{x,y,z},{2.8f,4.1f,0.14f},base);
    appendBox(v,{x-1.28f,y,z+0.09f},{0.08f,3.85f,0.035f},accent);
    appendBox(v,{x+1.28f,y,z+0.09f},{0.08f,3.85f,0.035f},accent);
    for(int i=0;i<3;++i) appendBox(v,{x+0.68f+0.18f*i,y-1.55f+0.18f*i,z+0.11f},{0.09f,0.9f,0.04f},accent,0.45f);
    // Angular team emblem built from short glowing bars.
    appendBox(v,{x,y+1.10f,z+0.12f},{0.95f,0.10f,0.04f},accent,0.0f);
    appendBox(v,{x-0.36f,y+0.78f,z+0.12f},{0.10f,0.70f,0.04f},accent,-0.50f);
    appendBox(v,{x+0.36f,y+0.78f,z+0.12f},{0.10f,0.70f,0.04f},accent,0.50f);
}

std::vector<Vertex> buildArenaMap() {
    std::vector<Vertex> v;v.reserve(18000);
    const Vec3 concrete{0.34f,0.39f,0.43f},darkConcrete{0.19f,0.23f,0.28f},metal{0.12f,0.17f,0.22f};
    const Vec3 cyan{0.02f,0.78f,1.0f},cyanDim{0.02f,0.35f,0.48f},orange{1.0f,0.34f,0.07f},warm{1.0f,0.68f,0.28f};

    // Dusk backdrop and mountain silhouettes.
    appendBox(v,{0.0f,10.0f,-37.0f},{100.0f,65.0f,0.5f},{0.12f,0.14f,0.22f});
    appendTriangle(v,{-28.0f,0.0f,-29.0f},{-18.0f,11.0f,-29.0f},{-8.0f,0.0f,-29.0f},{0.25f,0.28f,0.38f});
    appendTriangle(v,{-19.0f,0.0f,-28.8f},{-9.0f,13.0f,-28.8f},{2.0f,0.0f,-28.8f},{0.31f,0.33f,0.43f});
    appendTriangle(v,{-6.0f,0.0f,-29.2f},{4.0f,10.0f,-29.2f},{15.0f,0.0f,-29.2f},{0.23f,0.27f,0.37f});
    appendTriangle(v,{8.0f,0.0f,-29.1f},{18.0f,12.0f,-29.1f},{29.0f,0.0f,-29.1f},{0.28f,0.31f,0.42f});

    // Main wet concrete arena slab, tile seams and painted safety lanes.
    appendBox(v,{0.0f,-0.28f,-6.0f},{30.0f,0.55f,35.0f},{0.20f,0.25f,0.29f});
    for(int x=-12;x<=12;x+=3) appendBox(v,{static_cast<float>(x),0.012f,-6.0f},{0.025f,0.012f,33.0f},{0.31f,0.36f,0.40f});
    for(int z=-21;z<=9;z+=3) appendBox(v,{0.0f,0.014f,static_cast<float>(z)},{28.0f,0.012f,0.025f},{0.29f,0.34f,0.38f});
    appendBox(v,{-10.5f,0.025f,1.0f},{0.16f,0.025f,8.0f},orange);
    appendBox(v,{10.5f,0.025f,-3.0f},{0.16f,0.025f,8.0f},orange);
    appendBox(v,{0.0f,0.025f,-19.8f},{13.0f,0.025f,0.12f},{0.65f,0.69f,0.70f});
    for(int i=0;i<8;++i) appendBox(v,{-2.5f+static_cast<float>(i)*0.72f,0.035f,-2.7f},{0.42f,0.025f,0.12f},{0.75f,0.78f,0.78f},-0.18f);
    // Orange corner marking in the near-right foreground.
    appendBox(v,{8.5f,0.035f,1.2f},{4.5f,0.025f,0.16f},orange);
    appendBox(v,{10.7f,0.035f,-0.4f},{0.16f,0.025f,3.2f},orange);

    // Outer perimeter walls.
    appendBox(v,{-14.6f,2.4f,-6.0f},{0.65f,4.8f,34.0f},darkConcrete);
    appendBox(v,{14.6f,2.4f,-6.0f},{0.65f,4.8f,34.0f},darkConcrete);
    appendBox(v,{0.0f,2.8f,-23.2f},{29.0f,5.6f,0.65f},darkConcrete);

    // LEFT BUNKER / TEAM GRAN entrance structure.
    appendBox(v,{-13.0f,4.2f,-4.7f},{2.8f,8.4f,7.2f},concrete);
    appendBox(v,{-7.7f,4.2f,-4.7f},{2.0f,8.4f,7.2f},concrete);
    appendBox(v,{-10.25f,7.95f,-4.7f},{7.4f,1.0f,7.2f},concrete);
    appendBox(v,{-10.25f,0.55f,-4.7f},{7.4f,1.1f,7.2f},darkConcrete);
    // Dark doorway tunnel and interior floor.
    appendBox(v,{-10.25f,3.5f,-1.02f},{3.0f,5.8f,0.16f},{0.025f,0.035f,0.045f});
    appendBox(v,{-10.25f,0.12f,-0.15f},{3.0f,0.10f,5.0f},{0.16f,0.20f,0.24f});
    appendBox(v,{-11.85f,3.2f,-1.0f},{0.18f,5.7f,0.35f},orange);
    appendBox(v,{-8.65f,3.2f,-1.0f},{0.18f,5.7f,0.35f},orange);
    for(int i=0;i<4;++i) appendBox(v,{-10.25f,5.8f,-1.4f-static_cast<float>(i)*0.85f},{2.6f,0.08f,0.08f},warm);
    appendBanner(v,-10.25f,5.85f,-0.98f,false);
    appendText(v,"TEAM",-10.25f,5.25f,-0.875f,0.075f,{0.90f,0.92f,0.94f});
    appendText(v,"GRAN",-10.25f,4.72f,-0.875f,0.105f,{0.96f,0.96f,0.97f});
    // Utility cabinets and orange hazard strips around the doorway.
    appendBox(v,{-14.2f,1.9f,-0.75f},{0.55f,2.0f,0.55f},{0.25f,0.30f,0.34f});
    appendBox(v,{-6.5f,1.7f,-0.9f},{0.45f,1.7f,0.55f},{0.23f,0.28f,0.33f});
    for(int i=0;i<5;++i) appendBox(v,{-7.1f+0.25f*i,1.0f,-0.92f},{0.12f,1.2f,0.04f},orange,0.55f);
    appendBox(v,{-12.9f,8.65f,-4.7f},{3.0f,0.25f,7.5f},metal);

    // RIGHT A-03 TRAINING ARENA building.
    appendBox(v,{7.7f,3.7f,-11.2f},{11.8f,7.4f,7.8f},concrete);
    appendBox(v,{7.7f,0.45f,-7.2f},{11.8f,0.9f,0.25f},darkConcrete);
    // Wall reinforcement and upper lip.
    appendBox(v,{7.7f,7.45f,-7.22f},{12.0f,0.28f,0.34f},metal);
    for(int i=0;i<6;++i) appendBox(v,{2.3f+static_cast<float>(i)*2.0f,3.9f,-7.18f},{0.07f,7.0f,0.06f},shade(concrete,0.72f));
    appendText(v,"A-03",4.1f,5.0f,-7.02f,0.19f,{0.78f,0.82f,0.84f});
    appendText(v,"TRAINING ARENA",4.5f,4.15f,-7.01f,0.055f,{0.70f,0.75f,0.78f});
    for(int i=0;i<3;++i) appendBox(v,{6.0f+0.42f*i,4.9f,-7.02f},{0.18f,1.1f,0.04f},{0.68f,0.73f,0.75f},0.45f);

    // Holographic custom-mode panel on the right wall.
    appendBox(v,{9.3f,4.55f,-7.00f},{3.0f,2.8f,0.12f},{0.025f,0.075f,0.10f});
    appendBox(v,{9.3f,5.93f,-6.91f},{3.0f,0.045f,0.035f},cyan);
    appendBox(v,{9.3f,3.17f,-6.91f},{3.0f,0.045f,0.035f},cyanDim);
    appendBox(v,{7.82f,4.55f,-6.91f},{0.045f,2.8f,0.035f},cyanDim);
    appendBox(v,{10.78f,4.55f,-6.91f},{0.045f,2.8f,0.035f},cyanDim);
    appendText(v,"CUSTOM MODE",9.3f,5.55f,-6.88f,0.042f,cyan);
    const char* modeLabels[]={"CAPTURE","PLANT","DEFEND","CONTROL"};
    for(int i=0;i<4;++i) {
        float yy=5.0f-static_cast<float>(i)*0.48f;
        appendBox(v,{8.15f,yy,-6.88f},{0.18f,0.18f,0.035f},i==0?cyan:Vec3{0.22f,0.34f,0.39f});
        appendText(v,modeLabels[i],9.45f,yy,-6.86f,0.048f,i==0?Vec3{0.72f,0.96f,1.0f}:Vec3{0.62f,0.72f,0.76f});
    }

    // Glass command room above the right building.
    appendBox(v,{7.9f,8.75f,-11.2f},{9.4f,2.8f,6.8f},metal);
    appendBox(v,{7.9f,10.18f,-11.2f},{9.7f,0.22f,7.0f},{0.07f,0.10f,0.14f});
    appendBox(v,{7.9f,7.33f,-11.2f},{9.7f,0.22f,7.0f},{0.07f,0.10f,0.14f});
    // Front glass panes and dark mullions.
    for(int i=0;i<5;++i) {
        float x=4.0f+static_cast<float>(i)*1.95f;
        appendBox(v,{x,8.75f,-7.72f},{1.72f,2.35f,0.08f},{0.08f,0.27f,0.36f});
        appendBox(v,{x-0.92f,8.75f,-7.65f},{0.08f,2.55f,0.12f},{0.08f,0.12f,0.16f});
        // Blue monitor glow behind the windows.
        appendBox(v,{x,8.45f,-7.58f},{0.82f,0.52f,0.035f},{0.02f,0.40f,0.62f});
        appendBox(v,{x,9.20f,-7.58f},{0.55f,0.20f,0.035f},{0.04f,0.55f,0.78f});
    }
    appendBox(v,{7.9f,8.75f,-14.62f},{9.5f,2.7f,0.18f},{0.09f,0.13f,0.17f});

    // TEAM VOLT banner on the far right wall.
    appendBanner(v,12.0f,5.65f,-7.00f,true);
    appendText(v,"TEAM",12.0f,5.05f,-6.88f,0.075f,{0.90f,0.95f,0.98f});
    appendText(v,"VOLT",12.0f,4.52f,-6.88f,0.105f,{0.90f,0.95f,0.98f});

    // Elevated bridge / catwalk spanning the arena.
    appendBox(v,{-2.4f,5.35f,-5.4f},{15.5f,0.34f,1.45f},metal);
    appendBox(v,{-2.4f,5.58f,-5.4f},{15.5f,0.08f,1.45f},{0.25f,0.31f,0.36f});
    appendBox(v,{-2.4f,6.15f,-6.10f},{15.5f,0.12f,0.12f},{0.18f,0.23f,0.28f});
    appendBox(v,{-2.4f,6.15f,-4.70f},{15.5f,0.12f,0.12f},{0.18f,0.23f,0.28f});
    for(int i=0;i<16;++i) {
        float x=-9.7f+static_cast<float>(i)*0.98f;
        appendBox(v,{x,5.92f,-6.10f},{0.08f,0.52f,0.08f},metal);
        appendBox(v,{x,5.92f,-4.70f},{0.08f,0.52f,0.08f},metal);
        if(i%3==0) appendBox(v,{x,6.28f,-5.4f},{0.22f,0.08f,0.12f},warm);
    }
    // Truss supports and legs.
    for(float x : {-8.5f,-2.0f,3.2f}) {
        appendBox(v,{x,2.75f,-5.4f},{0.28f,5.5f,0.28f},metal);
        appendBox(v,{x,3.7f,-5.95f},{0.13f,3.2f,0.13f},metal,0.45f);
        appendBox(v,{x,3.7f,-4.85f},{0.13f,3.2f,0.13f},metal,-0.45f);
    }

    // Distant communication towers and beacons.
    for(float x : {-5.8f,1.7f}) {
        appendBox(v,{x,4.4f,-24.2f},{0.28f,8.8f,0.28f},metal);
        for(int i=0;i<5;++i) appendBox(v,{x,1.2f+static_cast<float>(i)*1.55f,-24.2f},{1.1f,0.10f,0.10f},metal);
        appendBox(v,{x,8.95f,-24.2f},{0.75f,0.18f,0.75f},warm);
    }

    // Central A capture point: segmented neon rings and central device crate.
    appendRing(v,0.0f,-11.2f,0.055f,3.55f,0.36f,cyan,72);
    appendRing(v,0.0f,-11.2f,0.062f,2.65f,0.28f,cyanDim,64);
    appendRing(v,0.0f,-11.2f,0.070f,1.75f,0.22f,cyan,56);
    appendBox(v,{0.0f,0.48f,-11.2f},{2.25f,0.95f,1.65f},{0.16f,0.22f,0.27f});
    appendBox(v,{0.0f,0.98f,-11.2f},{1.85f,0.08f,1.32f},{0.10f,0.17f,0.22f});
    for(int side=-1;side<=1;side+=2) {
        appendBox(v,{static_cast<float>(side)*1.12f,0.52f,-11.2f},{0.08f,0.75f,1.5f},cyanDim);
        appendBox(v,{static_cast<float>(side)*0.65f,0.52f,-12.04f},{0.22f,0.16f,0.05f},warm);
    }
    appendBox(v,{0.0f,1.05f,-11.2f},{0.82f,0.05f,0.62f},cyan);
    // Holographic beacon mast and diamond A marker facing the player.
    appendBox(v,{0.0f,2.05f,-11.2f},{0.06f,1.95f,0.06f},cyanDim);
    appendBox(v,{0.0f,3.18f,-11.14f},{1.0f,0.07f,0.05f},cyan,0.72f);
    appendBox(v,{0.0f,3.18f,-11.14f},{1.0f,0.07f,0.05f},cyan,-0.72f);
    appendBox(v,{-0.34f,2.83f,-11.14f},{0.07f,0.55f,0.05f},cyan,0.72f);
    appendBox(v,{0.34f,2.83f,-11.14f},{0.07f,0.55f,0.05f},cyan,-0.72f);
    appendText(v,"A",0.0f,3.12f,-11.08f,0.11f,{0.86f,0.98f,1.0f});
    for(int i=0;i<3;++i) appendBox(v,{0.0f,2.35f-static_cast<float>(i)*0.22f,-11.08f},{0.30f,0.07f,0.045f},cyan,0.0f);

    // Concrete cover blocks distributed around lanes.
    appendBox(v,{-6.0f,0.82f,-8.4f},{2.5f,1.65f,1.45f},{0.42f,0.46f,0.48f});
    appendBox(v,{-2.8f,0.72f,-6.8f},{1.8f,1.45f,1.3f},{0.38f,0.44f,0.48f});
    appendBox(v,{3.6f,0.75f,-7.8f},{2.1f,1.5f,1.45f},{0.40f,0.46f,0.49f});
    appendBox(v,{5.4f,0.82f,-12.5f},{2.0f,1.65f,1.4f},{0.40f,0.46f,0.49f});
    appendBox(v,{-4.2f,0.55f,-16.4f},{1.8f,1.1f,1.3f},{0.39f,0.45f,0.48f});
    appendBox(v,{1.8f,0.55f,-17.4f},{1.7f,1.1f,1.2f},{0.39f,0.45f,0.48f});
    // Hazard markers on cover faces.
    for(float x : {-6.0f,3.6f,5.4f}) {
        appendBox(v,{x,0.95f,-7.63f},{0.18f,0.22f,0.04f},orange);
        appendBox(v,{x+0.22f,0.95f,-7.63f},{0.18f,0.22f,0.04f},warm);
    }

    // Right-side stacked equipment cases, including V-077 ID case.
    auto crate=[&](float x,float y,float z,float sx,float sy,float sz,Vec3 accent) {
        appendBox(v,{x,y,z},{sx,sy,sz},{0.10f,0.14f,0.18f});
        appendBox(v,{x,y+sy*0.5f-0.08f,z+sz*0.5f+0.035f},{sx*0.82f,0.08f,0.045f},{0.20f,0.27f,0.32f});
        appendBox(v,{x-sx*0.5f+0.08f,y,z+sz*0.5f+0.04f},{0.08f,sy*0.82f,0.05f},accent);
        appendBox(v,{x+sx*0.5f-0.08f,y,z+sz*0.5f+0.04f},{0.08f,sy*0.82f,0.05f},accent);
    };
    crate(11.8f,0.9f,-9.8f,2.5f,1.8f,1.8f,orange);
    crate(11.8f,2.8f,-10.0f,2.3f,1.7f,1.7f,cyanDim);
    crate(9.5f,0.55f,-13.5f,1.8f,1.1f,1.5f,orange);
    crate(10.7f,1.65f,-14.4f,1.8f,1.1f,1.5f,cyanDim);
    appendText(v,"V-077",11.8f,0.90f,-8.84f,0.055f,{0.78f,0.84f,0.87f});

    // Foreground signature barricade with orange hazard paint and warm inset lamps.
    appendBox(v,{-9.0f,1.15f,2.7f},{5.2f,2.3f,1.2f},{0.38f,0.42f,0.43f});
    for(int i=0;i<5;++i) appendBox(v,{-10.6f+static_cast<float>(i)*0.62f,1.05f,3.33f},{0.30f,1.2f,0.06f},orange,0.55f);
    appendBox(v,{-9.0f,0.20f,3.35f},{1.1f,0.10f,0.06f},warm);
    appendBox(v,{-11.0f,0.20f,3.35f},{0.65f,0.10f,0.06f},warm);
    appendBox(v,{-7.0f,0.20f,3.35f},{0.65f,0.10f,0.06f},warm);

    // Cable run across the wet floor, segmented to create a curved path.
    const std::array<Vec3,8> cable={{{-7.0f,0.07f,1.0f},{-5.5f,0.07f,-0.2f},{-3.5f,0.07f,-1.5f},{-1.2f,0.07f,-2.3f},{1.2f,0.07f,-2.8f},{4.0f,0.07f,-2.7f},{6.4f,0.07f,-1.7f},{8.2f,0.07f,-0.1f}}};
    for(size_t i=0;i+1<cable.size();++i) {
        Vec3 a=cable[i],b=cable[i+1],d=b-a;float len=std::sqrt(d.x*d.x+d.z*d.z);float yaw=std::atan2(-d.z,d.x);
        appendBox(v,(a+b)*0.5f,{len,0.075f,0.075f},{0.035f,0.045f,0.055f},yaw);
    }

    // Industrial light strips around the arena, orange practical lights and cyan guide strips.
    for(float x : {-13.4f,-5.8f,0.0f,5.8f,13.4f}) {
        appendBox(v,{x,3.1f,-7.0f},{0.75f,0.12f,0.08f},warm);
        appendBox(v,{x,0.18f,-20.5f},{0.95f,0.06f,0.08f},cyanDim);
    }
    for(int i=0;i<6;++i) appendBox(v,{-12.7f+static_cast<float>(i)*0.8f,0.10f,-0.5f},{0.48f,0.06f,0.06f},warm);

    return v;
}

void setupVertexArray(GLuint vao,GLuint vbo,const std::vector<Vertex>& vertices,GLenum usage) {
    glBindVertexArray(vao);glBindBuffer(GL_ARRAY_BUFFER,vbo);
    glBufferData(GL_ARRAY_BUFFER,static_cast<GLsizeiptr>(vertices.size()*sizeof(Vertex)),vertices.empty()?nullptr:vertices.data(),usage);
    glEnableVertexAttribArray(0);glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,sizeof(Vertex),reinterpret_cast<void*>(offsetof(Vertex,px)));
    glEnableVertexAttribArray(1);glVertexAttribPointer(1,3,GL_FLOAT,GL_FALSE,sizeof(Vertex),reinterpret_cast<void*>(offsetof(Vertex,r)));
    glBindVertexArray(0);
}
void drawCube(const Mat4& vp,Vec3 position,Vec3 scale,Vec3 tint) {
    Mat4 model=multiply(translation(position.x,position.y,position.z),scaling(scale.x,scale.y,scale.z));Mat4 mvp=multiply(vp,model);
    glUseProgram(gProgram);glUniformMatrix4fv(gMvpLocation,1,GL_FALSE,mvp.v);glUniform3f(gTintLocation,tint.x,tint.y,tint.z);
    glBindVertexArray(gCubeVao);glDrawArrays(GL_TRIANGLES,0,36);
}
void drawMap(const Mat4& vp) {
    glUseProgram(gProgram);glUniformMatrix4fv(gMvpLocation,1,GL_FALSE,vp.v);glUniform3f(gTintLocation,1.0f,1.0f,1.0f);
    glBindVertexArray(gMapVao);glDrawArrays(GL_TRIANGLES,0,gMapVertexCount);glBindVertexArray(0);
}
void addLine(std::vector<Vertex>& v,float x1,float y1,float x2,float y2,float r,float g,float b) {
    v.push_back({x1,y1,0.0f,r,g,b});v.push_back({x2,y2,0.0f,r,g,b});
}
void addCircle(std::vector<Vertex>& v,float cx,float cy,float radius,float r,float g,float b) {
    constexpr int n=36;for(int i=0;i<n;++i){float a0=2.0f*PI*i/n,a1=2.0f*PI*(i+1)/n;addLine(v,cx+std::cos(a0)*radius,cy+std::sin(a0)*radius,cx+std::cos(a1)*radius,cy+std::sin(a1)*radius,r,g,b);}
}
void drawHud(float moveX,float moveY) {
    std::vector<Vertex> lines;lines.reserve(220);
    addLine(lines,-0.025f,0.0f,-0.008f,0.0f,0.92f,0.98f,1.0f);addLine(lines,0.008f,0.0f,0.025f,0.0f,0.92f,0.98f,1.0f);
    addLine(lines,0.0f,-0.025f,0.0f,-0.008f,0.92f,0.98f,1.0f);addLine(lines,0.0f,0.008f,0.0f,0.025f,0.92f,0.98f,1.0f);
    addCircle(lines,-0.72f,-0.60f,0.15f,0.42f,0.70f,0.84f);addCircle(lines,-0.72f+moveX*0.085f,-0.60f-moveY*0.085f,0.065f,0.78f,0.91f,1.0f);
    addCircle(lines,0.79f,-0.58f,0.105f,1.0f,0.48f,0.25f);addLine(lines,0.755f,-0.58f,0.825f,-0.58f,1.0f,0.70f,0.48f);addLine(lines,0.79f,-0.615f,0.79f,-0.545f,1.0f,0.70f,0.48f);
    if(gFireFlash>0.0f)addCircle(lines,0.0f,0.0f,0.045f,1.0f,0.72f,0.30f);
    if(gHitFlash>0.0f){addLine(lines,-0.045f,0.045f,-0.018f,0.018f,0.25f,1.0f,0.55f);addLine(lines,0.045f,0.045f,0.018f,0.018f,0.25f,1.0f,0.55f);addLine(lines,-0.045f,-0.045f,-0.018f,-0.018f,0.25f,1.0f,0.55f);addLine(lines,0.045f,-0.045f,0.018f,-0.018f,0.25f,1.0f,0.55f);}
    Mat4 id=identity();glDisable(GL_DEPTH_TEST);glUseProgram(gProgram);glUniformMatrix4fv(gMvpLocation,1,GL_FALSE,id.v);glUniform3f(gTintLocation,1,1,1);
    glBindVertexArray(gOverlayVao);glBindBuffer(GL_ARRAY_BUFFER,gOverlayVbo);glBufferData(GL_ARRAY_BUFFER,static_cast<GLsizeiptr>(lines.size()*sizeof(Vertex)),lines.data(),GL_DYNAMIC_DRAW);
    glEnableVertexAttribArray(0);glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,sizeof(Vertex),reinterpret_cast<void*>(offsetof(Vertex,px)));
    glEnableVertexAttribArray(1);glVertexAttribPointer(1,3,GL_FLOAT,GL_FALSE,sizeof(Vertex),reinterpret_cast<void*>(offsetof(Vertex,r)));
    glLineWidth(2.0f);glDrawArrays(GL_LINES,0,static_cast<GLsizei>(lines.size()));glBindVertexArray(0);glEnable(GL_DEPTH_TEST);
}
void shoot(Vec3 forward) {
    gFireFlash=0.10f;bool hit=false;
    for(auto& t:gTargets){if(!t.active)continue;Vec3 to=t.position-gPlayer;float along=dot(to,forward);if(along<=0.0f||along>28.0f)continue;Vec3 closest=gPlayer+forward*along;float miss=std::sqrt(dot(t.position-closest,t.position-closest));if(miss<0.82f){t.health--;if(t.health<=0)t.active=false;hit=true;break;}}
    if(hit)gHitFlash=0.22f;
}
void renderFrame() {
    float moveX,moveY,yaw,pitch;int fireCount;
    {std::lock_guard<std::mutex> lock(gInputMutex);moveX=gMoveX;moveY=gMoveY;yaw=gYaw;pitch=gPitch;fireCount=gFireRequests;gFireRequests=0;}
    auto now=std::chrono::steady_clock::now();float dt=std::chrono::duration<float>(now-gLastFrame).count();gLastFrame=now;dt=std::clamp(dt,0.0f,0.05f);
    float cp=std::cos(pitch);Vec3 forward=normalize({std::sin(yaw)*cp,std::sin(pitch),-std::cos(yaw)*cp});Vec3 right=normalize({std::cos(yaw),0.0f,std::sin(yaw)});
    Vec3 wish=forward*(-moveY)+right*moveX;float len=std::sqrt(wish.x*wish.x+wish.z*wish.z);if(len>1.0f){wish.x/=len;wish.z/=len;}
    gPlayer.x=std::clamp(gPlayer.x+wish.x*4.2f*dt,-12.8f,12.8f);gPlayer.z=std::clamp(gPlayer.z+wish.z*4.2f*dt,-19.8f,8.5f);
    for(int i=0;i<fireCount;++i)shoot(forward);gFireFlash=std::max(0.0f,gFireFlash-dt);gHitFlash=std::max(0.0f,gHitFlash-dt);
    Vec3 target=gPlayer+forward;Mat4 view=lookAt(gPlayer,target,{0,1,0});Mat4 projection=perspective(60.0f*PI/180.0f,gAspect,0.1f,120.0f);Mat4 vp=multiply(projection,view);
    glClearColor(0.055f,0.065f,0.105f,1.0f);glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);glEnable(GL_DEPTH_TEST);glDepthFunc(GL_LEQUAL);
    drawMap(vp);
    for(const auto& t:gTargets)if(t.active){Vec3 tint=t.health==3?Vec3{0.92f,0.22f,0.16f}:t.health==2?Vec3{0.98f,0.48f,0.12f}:Vec3{0.95f,0.78f,0.18f};drawCube(vp,t.position,{0.72f,1.25f,0.42f},tint);drawCube(vp,{t.position.x,t.position.y+0.45f,t.position.z+0.22f},{0.30f,0.30f,0.08f},{0.12f,0.16f,0.20f});}
    // First-person placeholder rifle, positioned low-right in the view.
    Vec3 gunBase=gPlayer+forward*0.72f+right*0.28f+Vec3{0.0f,-0.25f,0.0f};
    drawCube(vp,gunBase,{0.18f,0.16f,0.58f},{0.12f,0.16f,0.19f});
    drawCube(vp,gunBase+forward*0.28f+Vec3{0.0f,0.035f,0.0f},{0.075f,0.075f,0.34f},{0.27f,0.32f,0.35f});
    drawHud(moveX,moveY);
}

} // namespace

extern "C" JNIEXPORT void JNICALL Java_com_kontur_engine_MainActivity_nativeOnSurfaceCreated(JNIEnv*,jclass) {
    gProgram=createProgram();if(!gProgram){LOGE("Could not create shader program");return;}
    gMvpLocation=glGetUniformLocation(gProgram,"uMVP");gTintLocation=glGetUniformLocation(gProgram,"uTint");
    std::vector<Vertex> cube;cube.reserve(36);appendBox(cube,{0,0,0},{1,1,1},{1,1,1});
    glGenVertexArrays(1,&gCubeVao);glGenBuffers(1,&gCubeVbo);setupVertexArray(gCubeVao,gCubeVbo,cube,GL_STATIC_DRAW);
    std::vector<Vertex> map=buildArenaMap();gMapVertexCount=static_cast<GLsizei>(map.size());
    glGenVertexArrays(1,&gMapVao);glGenBuffers(1,&gMapVbo);setupVertexArray(gMapVao,gMapVbo,map,GL_STATIC_DRAW);
    glGenVertexArrays(1,&gOverlayVao);glGenBuffers(1,&gOverlayVbo);glEnable(GL_DEPTH_TEST);glClearDepthf(1.0f);gLastFrame=std::chrono::steady_clock::now();
    LOGI("KONTUR ENGINE 0.2 map initialized: %d vertices",gMapVertexCount);
}
extern "C" JNIEXPORT void JNICALL Java_com_kontur_engine_MainActivity_nativeOnSurfaceChanged(JNIEnv*,jclass,jint width,jint height) {
    gWidth=std::max(1,static_cast<int>(width));gHeight=std::max(1,static_cast<int>(height));gAspect=static_cast<float>(gWidth)/static_cast<float>(gHeight);glViewport(0,0,gWidth,gHeight);
}
extern "C" JNIEXPORT void JNICALL Java_com_kontur_engine_MainActivity_nativeOnDrawFrame(JNIEnv*,jclass){if(gProgram)renderFrame();}
extern "C" JNIEXPORT void JNICALL Java_com_kontur_engine_MainActivity_nativeSetMove(JNIEnv*,jclass,jfloat x,jfloat y){std::lock_guard<std::mutex> lock(gInputMutex);gMoveX=std::clamp(static_cast<float>(x),-1.0f,1.0f);gMoveY=std::clamp(static_cast<float>(y),-1.0f,1.0f);}
extern "C" JNIEXPORT void JNICALL Java_com_kontur_engine_MainActivity_nativeLook(JNIEnv*,jclass,jfloat dx,jfloat dy){std::lock_guard<std::mutex> lock(gInputMutex);gYaw+=static_cast<float>(dx);gPitch=std::clamp(gPitch-static_cast<float>(dy),-1.15f,1.15f);}
extern "C" JNIEXPORT void JNICALL Java_com_kontur_engine_MainActivity_nativeFire(JNIEnv*,jclass){std::lock_guard<std::mutex> lock(gInputMutex);gFireRequests=std::min(gFireRequests+1,8);}
