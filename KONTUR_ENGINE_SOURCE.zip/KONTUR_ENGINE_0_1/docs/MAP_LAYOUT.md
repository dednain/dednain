# A-03 Training Arena — map layout reference

The C++ renderer builds this level procedurally as one static mesh. Coordinates are in metres; the player starts near `(0, 1.65, 7)` looking toward negative Z.

## Major landmarks

- **Capture point A:** centre `(0, -11.2)` on the floor, with three cyan segmented rings, a central device crate and a holographic A marker.
- **Team Gran bunker:** left side, around `x = -10.25`, with an entrance tunnel, orange hazard details and a dark orange-accented banner.
- **Team Volt wall:** right side, around `x = 7.7`, with cyan banner, A-03 / TRAINING ARENA wall marking and a custom-mode panel.
- **Command room:** glass-fronted room above the right building, with cyan monitor panels.
- **Catwalk:** elevated bridge across the upper middle of the arena, with railings, support legs and warm warning lights.
- **Cover lanes:** concrete barricades around the capture ring, plus equipment cases on the right flank.
- **Foreground cover:** large orange-striped concrete barricade on the near-left side.
- **Backdrop:** dusk sky, distant mountain silhouettes and antenna towers.

## Visual target

The environment concept image is kept separately from this source-only archive. The current implementation matches its major composition and color blocking using procedural geometry. It is an early 3D blockout with stylized materials, not yet a photorealistic asset-for-asset recreation. Detailed PBR textures, modular authored meshes, physically based lighting, reflections and collision volumes are planned follow-up work.
