# KONTUR ENGINE 0.2 — A-03 Training Arena prototype

An original Android first-person shooter prototype. The engine core and renderer are written in C++ with OpenGL ES 3.0; Android supplies the app lifecycle, surface and touch events. It does not use Unity, Godot or Unreal.

## What's in this build

- Procedural 3D A-03 Training Arena map based on the project's original concept art (the reference PNG is stored separately)
- Team Gran bunker and orange banner
- Team Volt wall and cyan banner
- A-03 / TRAINING ARENA wall marking and custom-mode panel
- Glass command room, upper catwalk, supports and industrial lights
- Central cyan A capture objective, device crate and segmented rings
- Concrete cover blocks, equipment crates, foreground barricade and floor cable
- First-person camera, touch-look, movement stick, fire button and simple target hit detection
- GitHub Actions workflow that builds a debug APK and uploads it as an artifact

## Build locally

1. Install Android Studio.
2. In SDK Manager, install Android SDK Platform 35, Build Tools 35.0.0, NDK 27.2.12479018 and CMake 3.22.1.
3. Open this folder as an existing Android Studio project.
4. Wait for Gradle sync.
5. Connect an Android device with USB debugging enabled (or use an emulator with OpenGL ES 3.0 support).
6. Press **Run**.

The first Gradle sync requires an internet connection to download Gradle and the Android Gradle Plugin.

## Build APK with GitHub Actions

Push this project to a GitHub repository on `main`, `master` or `kontur-engine`, or open the Actions tab and run **Build KONTUR Android APK** manually. The workflow builds `app-debug.apk` and uploads it as the artifact `KONTUR-ENGINE-0.2-debug-apk`.

## Controls

- Drag on the left half of the screen to move.
- Drag on the right half to look around.
- Tap the bottom-right fire circle to shoot the training targets.

## Honest status

This is a playable-style early prototype and a procedural 3D blockout, not a finished commercial-quality shooter. The map's main layout and visual landmarks are represented, but the concept image cannot be converted automatically into exact production meshes. High-detail PBR materials, authored character and weapon models, animations, sound, robust collision, bots, match rules and online multiplayer are not included yet. The GitHub workflow is configured but has not been run in the user's repository, so no APK build is claimed yet.
